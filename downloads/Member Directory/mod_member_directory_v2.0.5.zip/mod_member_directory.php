<?php
/**
 * @package     Joomla.Site
 * @subpackage  mod_member_directory
 * 
 * This file is part of Member Directory Module.
 * 
 * Member Directory Module is a dual-licensed Joomla extension. The module's core 
 * functionality is released under GNU General Public License version 2 or later,
 * while the activation system and premium features are proprietary and require
 * a valid license key.
 *
 * @copyright   Copyright (C) 2026 Kabinary. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 *              The activation system and premium features are subject to additional
 *              terms. See LICENSE.txt for full license details.
 * @author      Kabinary <contact@kabinary.com>
 * @see         https://modules.kabinary.com for documentation and updates
 */

// Prevent direct access
defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Uri\Uri;
use Joomla\CMS\Helper\ModuleHelper;
use Joomla\Registry\Registry;

require_once dirname(__FILE__) . '/helper.php';

// Load language files
Factory::getLanguage()->load('mod_member_directory', JPATH_SITE.'/modules/mod_member_directory');
Factory::getDocument()->addStyleSheet(Uri::base() . 'modules/mod_member_directory/style.css');

try {
    $cache = Factory::getCache('mod_member_directory_users', 'callback');
    $cache->setCaching(true);
    $cache->setLifeTime(15);

    $cacheKeyUsers = md5(serialize($params) . Uri::root());
    $users = $cache->get(
        function() use ($params) {
            return ModMemberDirectoryHelper::getUsersFromCustomQuery($params);
        },
        array(), // Paramètres vides car on utilise use()
        $cacheKeyUsers // Clé de cache unique
    );

} catch (Exception $e) {
    // En cas d'erreur de cache, récupération directe
    $users = ModMemberDirectoryHelper::getUsersFromCustomQuery($params);
}

// Retrieve module parameters
$params = $module->params instanceof Registry ? $module->params : new Registry($module->params);

$subscriptionKey = trim($params->get('subscription_key', ''));
$apiUrl = "https://cms-mod.kabinary.com/api/subscriptions";
$validateSubscriptionEndpoint = $apiUrl . "/" . $subscriptionKey . "/validate";
$licensePurchaseUrl = "https://modules.kabinary.com/member-directory-module-license";
$clientName = trim($params->get('client_name', ''));
$clientEmail = trim($params->get('client_email', ''));

// Basic validation before calling the API
if (empty($subscriptionKey)) {
    echo '<div style="text-align: center;">
            <p class="error">' . Text::_('ERROR_LICENSE_MISSING') . '</p>
            <br><br>
            <a href="' . htmlspecialchars($licensePurchaseUrl, ENT_QUOTES, 'UTF-8') . '" 
               target="_blank" 
               class="btn btn-primary">
               ' . Text::_('GET_LICENSE') . '
            </a>
          </div>';
    return;
}
if (empty($clientName)) {
    echo '<div class="error">' . Text::_('ERROR_CLIENT_NAME_MISSING') . '</div>';
    return;
}
if (empty($clientEmail)) {
    echo '<div class="error">' . Text::_('ERROR_CLIENT_EMAIL_MISSING') . '</div>';
    return;
}

try {
    // Configuration du cache pour la validation de licence
    $cache = Factory::getCache('mod_member_directory_license', 'callback');
    $cache->setCaching(true);
    $cache->setLifeTime(1440);

    // Création d'une clé unique pour ce site et cette licence
    $cacheKey = md5($subscriptionKey . $clientName . $clientEmail . Uri::root());
    
    // Tentative de récupération depuis le cache
    $validationResult = $cache->get(
        function() use ($validateSubscriptionEndpoint, $clientName, $clientEmail) {
            return ModMemberDirectoryHelper::validateSubscription(
                $validateSubscriptionEndpoint, 
                $clientName, 
                $clientEmail
            );
        },
        array(), // Paramètres vides car on utilise use() 
        $cacheKey // Clé de cache unique
    );
} catch (Exception $e) {
    // En cas d'erreur de cache, on fait l'appel direct
    $validationResult = ModMemberDirectoryHelper::validateSubscription(
        $validateSubscriptionEndpoint, 
        $clientName, 
        $clientEmail
    );
}

if (!$validationResult['success']) {
    echo '<div class="error">' . htmlspecialchars($validationResult['message'], ENT_QUOTES, 'UTF-8') . '</div>';
    return;
}

// Retrieve contents from the API response
$moduleContent = $validationResult['subscription']['module'];
$htmlContent = $moduleContent['html'];
$cssContent = $moduleContent['css'];
$jsContent = $moduleContent['js'];

// Add RTL support for Arabic language
$lang = Factory::getLanguage();
if ($lang->isRTL()) {
    Factory::getDocument()->setDirection('rtl');
}

// Dynamically add CSS and JS if provided
if (!empty($cssContent)) {
    Factory::getDocument()->addStyleDeclaration($cssContent);
}

// Fetch users data using potential custom SQL
$users = ModMemberDirectoryHelper::getUsersFromCustomQuery($params);

// Pass the custom fields to the template
$customFields = $params->get('custom_fields');
// Ensure customFields is an array (already decoded by Joomla)
if (empty($customFields)) {
    $customFields = array();
} elseif (is_string($customFields)) {
    $customFields = json_decode($customFields);
    if (json_last_error() !== JSON_ERROR_NONE) {
        $customFields = array();
    }
}

// Pass translations to JavaScript
Factory::getDocument()->addScriptDeclaration('const translations = ' . json_encode($translations) . ';');

// Load the template
require ModuleHelper::getLayoutPath('mod_member_directory', 'default');